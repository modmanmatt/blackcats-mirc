#include <cstdio>
#include <cstring>
#include <string>
#include <windows.h>

#include "winamp.h"

int winamp_check(char *data)
{
	HWND hwndWinamp = FindWindow("Winamp v1.x",NULL);
	if(hwndWinamp == NULL)
	{
		hwndWinamp = FindWindow("STUDIO", NULL);
		if(hwndWinamp == NULL)
			sprintf(data, "0");
		else
			sprintf(data,"1");
	}
	else 
		sprintf(data, "1");

	return 3;
}

int winamp_play(char *data)
{
	HWND hwndWinamp = FindWindow("Winamp v1.x",NULL);
	if(hwndWinamp == NULL)
		hwndWinamp = FindWindow("STUDIO", NULL);
	SendMessage(hwndWinamp,WM_COMMAND, 40045, 0);

	return 3;
}

int winamp_pause(char *data)
{
	HWND hwndWinamp = FindWindow("Winamp v1.x",NULL);
	if(hwndWinamp == NULL)
		hwndWinamp = FindWindow("STUDIO", NULL);
	SendMessage(hwndWinamp,WM_COMMAND, 40046, 0);

	return 3;
}
int winamp_stop(char *data)
{
	HWND hwndWinamp = FindWindow("Winamp v1.x",NULL);
	if(hwndWinamp == NULL)
		hwndWinamp = FindWindow("STUDIO", NULL);
	SendMessage(hwndWinamp,WM_COMMAND, 40047, 0);

	return 3;
}
int winamp_next(char *data)
{
	HWND hwndWinamp = FindWindow("Winamp v1.x",NULL);
	if(hwndWinamp == NULL)
		hwndWinamp = FindWindow("STUDIO", NULL);
	SendMessage(hwndWinamp,WM_COMMAND, 40048, 0);

	return 3;
}
int winamp_previous(char *data)
{
	HWND hwndWinamp = FindWindow("Winamp v1.x",NULL);
	if(hwndWinamp == NULL)
		hwndWinamp = FindWindow("STUDIO", NULL);
	SendMessage(hwndWinamp,WM_COMMAND, 40044, 0);

	return 3;
}
int winamp_first(char *data)
{
	HWND hwndWinamp = FindWindow("Winamp v1.x",NULL);
	if(hwndWinamp == NULL)
		hwndWinamp = FindWindow("STUDIO", NULL);
	SendMessage(hwndWinamp,WM_COMMAND, 40154, 0);

	return 3;
}
int winamp_last(char *data)
{
	HWND hwndWinamp = FindWindow("Winamp v1.x",NULL);
	if(hwndWinamp == NULL)
		hwndWinamp = FindWindow("STUDIO", NULL);
	SendMessage(hwndWinamp,WM_COMMAND, 40158, 0);

	return 3;
}

int winamp_fname(char *data)
{
	HWND hWinamp = FindWindow("Winamp v1.x",NULL);

	if(hWinamp != NULL)
	{
		DWORD TempHandle, temp;

		int index = SendMessage(hWinamp, WM_USER, 0, 125);
		LPCVOID lpFileName = (LPCVOID)SendMessage(hWinamp, WM_USER, index, 211);

		GetWindowThreadProcessId(hWinamp, &TempHandle);
		HANDLE hWamp = OpenProcess(PROCESS_ALL_ACCESS, false, TempHandle);

		char sz_pli_Path[MAX_PATH];
		ReadProcessMemory(hWamp, lpFileName, sz_pli_Path, MAX_PATH, &temp);
		CloseHandle(hWamp);

		strcpy(data, sz_pli_Path);
	}
	else
		return 1;

	return 3;
}


int winamp_info_title(char *data)
{
	HWND hWinamp = FindWindow("Winamp v1.x",NULL);
	HWND hWinamp3 = FindWindow("STUDIO", NULL);

	char szTemp[1024];

	if(hWinamp != NULL)
	{
		GetWindowText(hWinamp, szTemp, 1024);
		std::string sTitle = szTemp;
		
		if(sTitle.find('.') != std::string::npos && sTitle.find('-') != std::string::npos)
		{
			sTitle = sTitle.substr(sTitle.find('.')+1, sTitle.rfind('-')-sTitle.find('.')-2);
			sTitle += '\0';
			strcpy(data, sTitle.c_str());
		}
	}
	else
		strcpy(data, "artist - track");



	return 3;
}
int winamp_info_elapsed(char *data)
{
	HWND hWinamp = FindWindow("Winamp v1.x",NULL);

	if(hWinamp != NULL)
		sprintf(data, "%i", SendMessage(hWinamp, WM_USER, 0, 105)/1000);
	else
	{
		hWinamp = FindWindow("STUDIO", NULL);

		if(hWinamp != NULL)
			sprintf(data, "%i", SendMessage(hWinamp, WM_USER, 0, 105)/1000);
	}

	return 3;
}
int winamp_info_length(char *data)
{
	HWND hWinamp = FindWindow("Winamp v1.x",NULL);

	if(hWinamp != NULL)
		sprintf(data, "%i",SendMessage(hWinamp, WM_USER, 1, 105));
	else
	{
		hWinamp = FindWindow("STUDIO", NULL);

		if(hWinamp != NULL)
			sprintf(data, "%i",SendMessage(hWinamp, WM_USER, 1, 105));
	}

	return 3;
}
int winamp_info_plcount(char *data)
{
	HWND hWinamp = FindWindow("Winamp v1.x",NULL);
	if(hWinamp != NULL)
		sprintf(data,"%i",SendMessage(hWinamp,WM_USER, 0, 124));
	
	return 3;
}
int winamp_info_plpos(char *data)
{
	HWND hWinamp = FindWindow("Winamp v1.x",NULL);
	if(hWinamp != NULL)
		sprintf(data,"%i",SendMessage(hWinamp,WM_USER, 0, 125) + 1);

	return 3;
}
int winamp_info_bitrate(char *data)
{
	HWND hWinamp = FindWindow("Winamp v1.x",NULL);

	if(hWinamp != NULL)
		sprintf(data, "%i kbit/s", SendMessage(hWinamp, WM_USER, 1, 126));

	return 3;
}