========================================================================
                           Winampcontroller v1.0
========================================================================

===================
  About
===================
   Author:	Tony Karlsson

   Contact:	tonyk_85@yahoo.co.uk

   About:	A script+dll that makes it posible to control winamp in mirc.
			Very simple and it's used without any plugin for winamp.
			Enjoy my creation!

   Notes:   If you have any questions or bug reports feel free to contact me.

===================
  known bugs
===================
 -	No known bugs