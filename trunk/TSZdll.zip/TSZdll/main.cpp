//**********************************************************************
//
//						Winamp Controller v1.0
//
//	Author:  Izzzo
//	
//	Contact: tonyk_85@yahoo.co.uk
//
//	About:   A script+dll that makes it posible to control winamp in mirc.
//		     Very simple and it's used without any plugin for winamp.
//
//**********************************************************************


#include <windows.h>

#include "winamp.h"
#include "outputmusiclist.h"

int __stdcall winamp(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause);
int __stdcall outputmusiclist(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause);


int WINAPI DllMain (HINSTANCE hInstance, DWORD fdwReason, PVOID pvReserved)
{
     return TRUE ;
}


int __stdcall outputmusiclist(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	int result = 3;

	if(strlen(data)>1)
	{
		if(data[0] == '1' && data[1] != '\0')
		{
			for(int i=0; i<strlen(data); i++)
			{
				data[i] = data[i+1];
			}
			return outputmusiclist_itemcount(data);
		}
		else if(data[0] == '2' && data[1] != '\0')
		{
			for(int i=0; i<strlen(data); i++)
			{
				data[i] = data[i+1];
			}
			return outputmusiclist_writelist(data);
		}
		else if(data[0] == '3' && data[1] != '\0')
		{
			for(int i=0; i<strlen(data); i++)
			{
				data[i] = data[i+1];
			}
			return outputmusiclist_updateservlist(data);
		}
	}

	return result;
}

int __stdcall winamp(HWND mWnd, HWND aWnd, char *data, char *parms, BOOL show, BOOL nopause)
{
	int result = 3;
	


	if(!strcmp(data,"_"))
		return 3;
	else if(!strcmp(data,"1"))
		return winamp_check(data);
	else if(!strcmp(data,"2"))
		return winamp_play(data);
	else if(!strcmp(data,"3"))
		return winamp_pause(data);
	else if(!strcmp(data,"4"))
		return winamp_stop(data);
	else if(!strcmp(data,"5"))
		return winamp_next(data);
	else if(!strcmp(data,"6"))
		return winamp_previous(data);
	else if(!strcmp(data,"7"))
		return winamp_first(data);
	else if(!strcmp(data,"8"))
		return winamp_last(data);

	else if(!strcmp(data,"9"))
		return winamp_fname(data);

	else if(!strcmp(data,"10"))
		return winamp_info_title(data);
	else if(!strcmp(data,"11"))
		return winamp_info_elapsed(data);
	else if(!strcmp(data,"12"))
		return winamp_info_length(data);
	else if(!strcmp(data,"13"))
		return winamp_info_plcount(data);
	else if(!strcmp(data,"14"))
		return winamp_info_plpos(data);
	else if(!strcmp(data,"15"))
		return winamp_info_bitrate(data);

	return result;
}