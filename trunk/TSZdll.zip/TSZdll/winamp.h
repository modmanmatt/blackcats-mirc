

int winamp_check(char *data);
int winamp_play(char *data);
int winamp_pause(char *data);
int winamp_stop(char *data);
int winamp_next(char *data);
int winamp_previous(char *data);
int winamp_first(char *data);
int winamp_last(char *data);

int winamp_fname(char *data);

int winamp_info_title(char *data);
int winamp_info_elapsed(char *data);
int winamp_info_length(char *data);
int winamp_info_plcount(char *data);
int winamp_info_plpos(char *data);
int winamp_info_bitrate(char *data);