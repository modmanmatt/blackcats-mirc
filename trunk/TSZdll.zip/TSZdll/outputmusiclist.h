#include <string>
#include <fstream>

int outputmusiclist_itemcount(char *data);
int outputmusiclist_writelist(char *data);
int outputmusiclist_updateservlist(char *data);

void outputmusiclist_recursivefilecount(std::string sPath, unsigned long int &nFileCount);
void outputmusiclist_recursivefilesoutput(std::string sPath, std::ofstream &fout);