#include <windows.h>

#include "outputmusiclist.h"

int outputmusiclist_itemcount(char *data)
{
	std::string sPath = data;
	if(sPath.at(sPath.size()-1) != '\\')
		sPath += '\\';
	sPath += "*.*";

	unsigned long int nFileCount = 0;

	outputmusiclist_recursivefilecount(sPath.c_str(), nFileCount);
	sprintf(data,"%i",nFileCount);

	return 3;
}

void outputmusiclist_recursivefilecount(std::string sPath, unsigned long int &nFileCount)
{
	HANDLE hSearch;
	WIN32_FIND_DATA ffd;

	hSearch = FindFirstFile(sPath.c_str(), &ffd);

	if(hSearch != NULL)
	{
		do
		{
			if(ffd.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY && (strcmp(ffd.cFileName, ".") != 0) && (strcmp(ffd.cFileName, "..") != 0))
			{
				std::string sNewPath = sPath.substr(0,sPath.rfind('\\')+1);
				sNewPath += ffd.cFileName;
				sNewPath += '\\';
				sNewPath += "*.*";
				outputmusiclist_recursivefilecount(sNewPath.c_str(), nFileCount);
			}
			else if(((std::string)ffd.cFileName).find('.') != std::string::npos)
			{
				std::string sExtension = ((std::string)ffd.cFileName).substr(((std::string)ffd.cFileName).rfind('.'),((std::string)ffd.cFileName).size()-((std::string)ffd.cFileName).rfind('.'));
				if(sExtension == ".mp3" || sExtension == ".wav" || sExtension == ".mid" || sExtension == ".midi" || sExtension == ".ogg")
					nFileCount++;
			}
		}
		while(FindNextFile(hSearch, &ffd) != 0);
	}
	FindClose(hSearch);
}

int outputmusiclist_writelist(char *data)
{
	std::string sPath = data;
	std::string sOutput = sPath.substr(sPath.find('|')+1, sPath.size()-sPath.find('|'));
	sPath = sPath.substr(0, sPath.find('|'));
	if(sPath.at(sPath.size()-1) != '\\')
		sPath += '\\';
	sPath += "*.*";

	std::ofstream fout(sOutput.c_str(), std::ios_base::app);

	if(fout)
	{
		outputmusiclist_recursivefilesoutput(sPath.c_str(), fout);

		fout.close();
		sprintf(data, "true");
	}
	else
		sprintf(data, "false");

	return 3;
}


void outputmusiclist_recursivefilesoutput(std::string sPath, std::ofstream &fout)
{
	HANDLE hSearch;
	WIN32_FIND_DATA ffd;

	hSearch = FindFirstFile(sPath.c_str(), &ffd);

	if(hSearch != NULL)
	{
		do
		{
			std::string sNewPath = sPath.substr(0,sPath.rfind('\\')+1);
			if(ffd.dwFileAttributes == FILE_ATTRIBUTE_DIRECTORY && (strcmp(ffd.cFileName, ".") != 0) && (strcmp(ffd.cFileName, "..") != 0))
			{
				sNewPath += ffd.cFileName;
				sNewPath += '\\';
				sNewPath += "*.*";
				outputmusiclist_recursivefilesoutput(sNewPath.c_str(), fout);
			}
			else if(((std::string)ffd.cFileName).find('.') != std::string::npos)
			{
				std::string sExtension = ((std::string)ffd.cFileName).substr(((std::string)ffd.cFileName).rfind('.'),((std::string)ffd.cFileName).size()-((std::string)ffd.cFileName).rfind('.'));
				if(sExtension == ".mp3" || sExtension == ".wav" || sExtension == ".mid" || sExtension == ".midi" || sExtension == ".ogg")
					fout << sNewPath.c_str() << ffd.cFileName << std::endl;
			}
		}
		while(FindNextFile(hSearch, &ffd) != 0);
	}
	FindClose(hSearch);
}

int outputmusiclist_updateservlist(char *data)
{
	std::string sData = data;
	std::string sNick = sData.substr(0, sData.find('|'));
	sData = sData.substr(sData.find('|')+1,sData.size()-sData.find('|'));

	std::string sTrigger = sData.substr(0, sData.find('|'));
	sData = sData.substr(sData.find('|')+1,sData.size()-sData.find('|'));

	std::string sInput = sData.substr(0, sData.find('|'));
	std::string sOutput = sData.substr(sData.find('|')+1,sData.size()-sData.find('|'));;

	std::ifstream fin(sInput.c_str(),std::ios_base::in);
	std::ofstream fout(sOutput.c_str(), std::ios_base::out | std::ios_base::app);

	if(fin.is_open() && fout.is_open())
	{
		char szFileline[MAX_PATH];
		while(fin.getline(szFileline,MAX_PATH))
			fout << "/msg " << sNick.c_str() << " " << sTrigger.c_str() << " " << szFileline << std::endl;
	}



	return 3;
}